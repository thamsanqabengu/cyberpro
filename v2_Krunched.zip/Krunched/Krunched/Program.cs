﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Krunched._helper.File;
using Krunched._helper.Strings;

namespace Krunched
{
    class Program
    {
        static void Main(string[] args)
        {
            //Defining input file location
            string _fileLocation = @"C:\Krushed\Input\TestFile.txt";
            Console.WriteLine("The Input file is: " + _fileLocation + ".");

            //Check if input file directory exists
            if (!Directory.Exists(@"C:\Krushed\Input\"))
            {
                //Create directory if it doesn't exist
                Directory.CreateDirectory(@"C:\Krushed\Input\");

                //Prompt use to create text file with their choice of data to be Krunched
                Console.WriteLine("The file 'TestFile.txt' does not exist in 'C:\\Krushed\\Input\\', please create file.");
            }
            else
            {
                //Otherwise start processing textfile.txt
                KrunchFile(_fileLocation);
            }


            //Pause App for debugging - remove before automation
            Console.ReadLine();
        }

        static void KrunchFile(string _fileLocation)
        {
            Read _objRead = new Read();
            CharCount _objCharCount = new CharCount();
            ToUppercase _objToUppercase = new ToUppercase();
            CharManipulation _charManipulation = new CharManipulation();
            Write _objWrite = new Write();

            string _inputString = "";
            int _countString = 0;

            //Instantiate object and file location to read the text file data from
            _objRead._fileLocation = _fileLocation;

            //Process file
            Console.WriteLine("The file from  - " + _fileLocation + " - is being processed.");
            _objRead.ProcessFile();

            //Check that the processed data is valid: null or empty
            if (!String.IsNullOrEmpty(_objRead._outputString))
            {
                //If valid then check that the data string character count if well within the specified range set out in the spec
                _inputString = _objRead._outputString ;
                Console.WriteLine("Status - Current output is: " + _inputString + ".");
                _objCharCount._inputString = _inputString;
                _objCharCount.CountString();
                _countString = _objCharCount._stringCount;
                Console.WriteLine("Status - Current output char count is: " + _countString);

                //If that processed string data charatcer count is valid
                if (_objCharCount._stringCount <= 2 || _objCharCount._stringCount <= 70)
                {
                    //If valid then uppercase string as set out in the spec
                    Console.WriteLine("Status - Current output char count within specified range.");
                    _objToUppercase._inputString = _inputString;
                    _objToUppercase.ManipulateString();
                    _inputString = _objToUppercase._outputString;
                    Console.WriteLine("Status - Current output char is now uppercase: " + _inputString);

                    //Now we are going to manipulate the string according to krnching rules
                    _charManipulation._inputString = _inputString;
                    _charManipulation.DuplicateFindRemove();
                    _inputString = _charManipulation._outputString;


                    Console.WriteLine("Status - Current output char is now krunched: " + _inputString);

                    Write _write = new Write();
                    _write._inputString = _inputString;

                    //Check if output file directories exist
                    _write.CheckForKrushedDirectory();
                    _write.CheckForOutputDirectory();

                    //if output directories exist
                    if (_write._krushedDirectoryExists)
                    {
                        if (_write._outputDirectoryExists)
                        {
                            //Write output file to disk
                            _write.WriteToFile();
                        }
                    }
                }
                else
                {
                    Console.WriteLine("The Input file text is either less than 2 or greater than 70 characters, please check file.");
                }
            }
            else
            {
                Console.WriteLine("The file is either empty or contains invalid characters, please check file.");
            }


            _objRead = null;
            _objCharCount = null;
            _objToUppercase = null;
            _charManipulation = null;
            _objWrite = null;
        }
    }
}
