﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Krunched._helper.File
{
    //This class expects an file location input string. It then reads the text file data
    //and then returns the file data as an output variable
    public class Read
    {
        public string _fileLocation { get; set; }
        public string _inputString { get; set; }
        public string _outputString { get; set; }

        //reads text from file
        public void ProcessFile()
        {
            try
            {
                //Opens file stream to read data
                StreamReader sr = new StreamReader(_fileLocation);
                _inputString = sr.ReadLine();

                //Loops through all lines in a file and appends to variable
                while (_inputString != null)
                {
                    Console.WriteLine("Current output string: " + _inputString);
                    _outputString += " " + _inputString;
                    _inputString = sr.ReadLine();
                }

                //Removes all leading and trailing spacess
                _outputString = _outputString.Trim();

                //Closes file stream
                sr.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message.ToString());
            }
            finally
            {
                Console.WriteLine("Final Input String: " + _outputString);
            }
        }
    }
}
