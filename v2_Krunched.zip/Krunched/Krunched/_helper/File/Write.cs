﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Krunched._helper.File
{
    public class Write
    {
        public string _inputString { get; set; }
        public bool _outputDirectoryExists { get; set; }
        public bool _krushedDirectoryExists { get; set; }

        public void CheckForOutputDirectory()
        {
            _outputDirectoryExists = false;

            if (!Directory.Exists(@"C:\Krushed\Output\"))
            {
                Console.WriteLine("The 'Output' Directory doesn't exist in C:\\Krushed\\");
                Console.WriteLine("The 'Output' Directory is being created on C:\\Krushed\\");
                Directory.CreateDirectory(@"C:\Krushed\Output\");
                Console.WriteLine("The 'Output' Directory created on 'C:\\Krushed\\");
                _outputDirectoryExists = true;
            }
            else
            {
                Console.WriteLine("The 'Output' Directory found in C:\\Krushed, output file TestFile.text can be created.");
                _outputDirectoryExists = true;
            }
        }
        public void CheckForKrushedDirectory()
        {
            _krushedDirectoryExists = false;

            if (!Directory.Exists(@"C:\Krushed\"))
            {
                Console.WriteLine("The 'Krushed' Directory doesn't exist in C:\\");
                Console.WriteLine("The 'Krushed' Directory is being created on C:\\");
                Directory.CreateDirectory(@"C:\Krushed\");
                Console.WriteLine("The 'Krushed' Directory created on C:\\");

                _krushedDirectoryExists = true;
            }
            else
            {
                Console.WriteLine("The 'Krushed' Directory found in C:\\.");
                _krushedDirectoryExists = true;
            }
        }
        public void WriteToFile()
        {
            System.IO.File.WriteAllText(@"C:\Krushed\Output\TestFile.txt", _inputString);
            Console.WriteLine("TestFile.txt created.");
        }
    }
}
