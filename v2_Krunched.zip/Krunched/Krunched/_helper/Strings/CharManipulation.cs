﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Krunched._helper.Strings
{
    //This class expects an input string which it then krunches and then returns the output string as an output variable
    public class CharManipulation
    {
        public string _inputString { get; set; }
        public string _outputString { get; set; }

        public void DuplicateFindRemove()
        {
            _outputString = "";
            try
            {
                //Removes all vowels from inputstring
                _inputString = _inputString.Replace("A", string.Empty)
                                         .Replace("E", string.Empty)
                                         .Replace("I", string.Empty)
                                         .Replace("O", string.Empty)
                                         .Replace("U", string.Empty);

                //Loops through characters of the input string
                foreach (char value in _inputString)
                {
                    //Adds all first instances of a character or whitespaces or underscores to output variable
                    if (_outputString.IndexOf(value) == -1 || Char.IsWhiteSpace(value) || value == '_')
                    {
                        _outputString += value;
                    }
                }
                
                //Remove Duplicate Whitespace
                RegexOptions _options = RegexOptions.None;
                Regex _regex = new Regex("[ ]{2,}", _options);
                _outputString = _regex.Replace(_outputString, " ");

                //Remove Duplicate Underscore
                Regex _regexBlank = new Regex("[_]{2,}", _options);
                _outputString = _regexBlank.Replace(_outputString, "_");
                _outputString = _outputString.TrimEnd('_');
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.Message.ToString());
            }
            finally
            {
                Console.WriteLine("Final Input String: " + _outputString);
            }
        }
    }
}
