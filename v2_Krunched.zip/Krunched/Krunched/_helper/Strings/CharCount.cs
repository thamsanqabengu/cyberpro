﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Krunched._helper.Strings
{
    //This class expects an input string for which it then determines the character 
    //count and then returns the count as an output variable
    public class CharCount
    {
        public string _inputString { get; set; }
        public int _stringCount { get; set; }

        //Determines the character count
        public void CountString()
        {
            _stringCount = _inputString.Count();
        }
    }
}
