﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Krunched._helper.Strings
{
    //This class expects an input string for which it then Uppercases the string in it's entirety 
    //and then returns the string as an output variable
    public class ToUppercase
    {
        public string _inputString { get; set; }
        public string _outputString { get; set; }

        //Uppercases input string
        public void ManipulateString()
        {
            _outputString = _inputString.ToUpper();
        }
    }
}
